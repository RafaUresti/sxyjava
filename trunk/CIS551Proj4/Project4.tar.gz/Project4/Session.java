public interface Session {
    public boolean authenticateUser();
    public boolean doTransaction();
}
