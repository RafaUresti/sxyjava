public interface LogInterface {
    
}
