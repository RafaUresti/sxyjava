public class AccountException extends Exception {
    public static final long serialVersionUID = 331002;
    public AccountException(String s) {
	super(s);
    }
}
