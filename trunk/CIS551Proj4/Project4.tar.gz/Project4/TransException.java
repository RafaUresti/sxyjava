public class TransException extends Exception {
    public static final long serialVersionUID = 331003;
    public TransException(String s) {
	super(s);
    }
}
